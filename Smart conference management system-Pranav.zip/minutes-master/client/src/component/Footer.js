import React, {Component} from 'react';

export default class Footer extends Component{
    render(){
        return <footer role="contentinfo" className="mt-auto bg-light text-center">
            Copyright &copy; 2018, Niti Singhal.
        </footer>;
    }
}