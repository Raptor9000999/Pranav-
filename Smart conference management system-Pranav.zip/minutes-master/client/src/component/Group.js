import React from 'react';

export default class Group extends React.Component {

    render() {
        return this.props.children;
    }

}