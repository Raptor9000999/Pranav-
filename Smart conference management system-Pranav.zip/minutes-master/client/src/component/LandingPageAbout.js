import React, {Component} from 'react';

export default class LandingPageAbout extends Component{
    render(){
        return(
            <div>
                
            </div>
        )
    }
}