import react, {Component} from 'react';

export default class SignUp extends Component{
    render(){
        return(
            <div>
                
            </div>
        )
    }
}