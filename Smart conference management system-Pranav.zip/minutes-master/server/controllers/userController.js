//connecting db
const mongoose = require('mongoose');

//adding models
const database = require('../models');

