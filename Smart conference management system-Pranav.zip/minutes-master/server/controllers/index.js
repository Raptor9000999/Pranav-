module.exports = {
    MeetingController: require('./meetingController'),
    TaskController: require('./taskController'),
    TeamController: require('./teamController'),
    UserController: require('./userController')
};